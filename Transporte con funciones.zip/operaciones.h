float precioRuta(int ruta, float km);
float descuento(float km, float s);